# 🎮 GameDrop — RGB Rainbow Game Download Site

Bu proje, RGB renkli animasyonlu arka planı olan, basit bir **oyun indirme sitesi** örneğidir.  
HTML, CSS ve JavaScript kullanılarak oluşturulmuştur.

## 🚀 Özellikler
- Renk geçişli (RGB rainbow) animasyonlu arka plan
- Arama çubuğu ile oyun filtreleme
- Dinamik olarak oluşturulan oyun kartları
- Modern ve cam efekti (glassmorphism) tasarımı

## 📂 Dosya Yapısı
```
/
├── index.html
├── style.css
├── script.js
└── img/
    ├── logo.svg
    ├── game1.svg
    ├── game2.svg
    ├── game3.svg
    └── game4.svg
```

## 💡 Kullanım
1. Tüm dosyaları bilgisayarına indir (`rgb_rainbow_game_site.zip`).
2. Dosyaları bir klasöre çıkart.
3. `index.html` dosyasını tarayıcıda aç.

## 🌈 Canlı Demo
GitHub Pages’e yüklediğinde otomatik olarak çalışır.

Örnek:  
```
https://kullaniciadi.github.io/rgb_rainbow_game_site/
```

## 🧠 Geliştirici Notu
Bu site bir **demo projesidir**. Gerçek indirme bağlantıları için sunucu tarafı (örneğin Node.js veya PHP) gerekir.
